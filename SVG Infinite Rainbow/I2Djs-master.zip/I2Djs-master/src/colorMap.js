/* eslint-disable no-undef */
;(function colorMap (root, factory) {
  const i2d = root
  if (typeof define === 'function' && define.amd) {
    define('colorMap', [], () => factory())
  } else if (typeof module === 'object' && module.exports) {
    module.exports.colorMap = factory()
  } else {
    i2d.colorMap = factory()
  }
}(this, () => {
  'use strict'
  const preDefinedColors = ['AliceBlue', 'AntiqueWhite', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque', 'Black', 'BlanchedAlmond', 'Blue', 'BlueViolet', 'Brown', 'BurlyWood', 'CadetBlue', 'Chartreuse', 'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan', 'DarkBlue', 'DarkCyan', 'DarkGoldenRod', 'DarkGray', 'DarkGrey', 'DarkGreen', 'DarkKhaki', 'DarkMagenta', 'DarkOliveGreen', 'DarkOrange', 'DarkOrchid', 'DarkRed', 'DarkSalmon', 'DarkSeaGreen', 'DarkSlateBlue', 'DarkSlateGray', 'DarkSlateGrey', 'DarkTurquoise', 'DarkViolet', 'DeepPink', 'DeepSkyBlue', 'DimGray', 'DimGrey', 'DodgerBlue', 'FireBrick', 'FloralWhite', 'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod', 'Gray', 'Grey', 'Green', 'GreenYellow', 'HoneyDew', 'HotPink', 'IndianRed', 'Indigo', 'Ivory', 'Khaki', 'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue', 'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGrey', 'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue', 'LightSlateGray', 'LightSlateGrey', 'LightSteelBlue', 'LightYellow', 'Lime', 'LimeGreen', 'Linen', 'Magenta', 'Maroon', 'MediumAquaMarine', 'MediumBlue', 'MediumOrchid', 'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen', 'MediumTurquoise', 'MediumVioletRed', 'MidnightBlue', 'MintCream', 'MistyRose', 'Moccasin', 'NavajoWhite', 'Navy', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed', 'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed', 'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple', 'RebeccaPurple', 'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Salmon', 'SandyBrown', 'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue', 'SlateGray', 'SlateGrey', 'Snow', 'SpringGreen', 'SteelBlue', 'Tan', 'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White', 'WhiteSmoke', 'Yellow', 'YellowGreen']

  const preDefinedColorHex = ['f0f8ff', 'faebd7', '00ffff', '7fffd4', 'f0ffff', 'f5f5dc', 'ffe4c4', '000000', 'ffebcd', '0000ff', '8a2be2', 'a52a2a', 'deb887', '5f9ea0', '7fff00', 'd2691e', 'ff7f50', '6495ed', 'fff8dc', 'dc143c', '00ffff', '00008b', '008b8b', 'b8860b', 'a9a9a9', 'a9a9a9', '006400', 'bdb76b', '8b008b', '556b2f', 'ff8c00', '9932cc', '8b0000', 'e9967a', '8fbc8f', '483d8b', '2f4f4f', '2f4f4f', '00ced1', '9400d3', 'ff1493', '00bfff', '696969', '696969', '1e90ff', 'b22222', 'fffaf0', '228b22', 'ff00ff', 'dcdcdc', 'f8f8ff', 'ffd700', 'daa520', '808080', '808080', '008000', 'adff2f', 'f0fff0', 'ff69b4', 'cd5c5c', '4b0082', 'fffff0', 'f0e68c', 'e6e6fa', 'fff0f5', '7cfc00', 'fffacd', 'add8e6', 'f08080', 'e0ffff', 'fafad2', 'd3d3d3', 'd3d3d3', '90ee90', 'ffb6c1', 'ffa07a', '20b2aa', '87cefa', '778899', '778899', 'b0c4de', 'ffffe0', '00ff00', '32cd32', 'faf0e6', 'ff00ff', '800000', '66cdaa', '0000cd', 'ba55d3', '9370db', '3cb371', '7b68ee', '00fa9a', '48d1cc', 'c71585', '191970', 'f5fffa', 'ffe4e1', 'ffe4b5', 'ffdead', '000080', 'fdf5e6', '808000', '6b8e23', 'ffa500', 'ff4500', 'da70d6', 'eee8aa', '98fb98', 'afeeee', 'db7093', 'ffefd5', 'ffdab9', 'cd853f', 'ffc0cb', 'dda0dd', 'b0e0e6', '800080', '663399', 'ff0000', 'bc8f8f', '4169e1', '8b4513', 'fa8072', 'f4a460', '2e8b57', 'fff5ee', 'a0522d', 'c0c0c0', '87ceeb', '6a5acd', '708090', '708090', 'fffafa', '00ff7f', '4682b4', 'd2b48c', '008080', 'd8bfd8', 'ff6347', '40e0d0', 'ee82ee', 'f5deb3', 'ffffff', 'f5f5f5', 'ffff00', '9acd32']

  const colorMap = {}
  const round = Math.round
  var defaultColor = 'rgba(0,0,0,0)'

  for (let i = 0; i < preDefinedColors.length; i += 1) {
    colorMap[preDefinedColors[i]] = preDefinedColorHex[i]
  }

  function RGBA (r, g, b, a) {
    this.r = r
    this.g = g
    this.b = b
    this.a = (a === undefined ? 255 : a)
    this.rgba = `rgb(${r},${g},${b},${a})`
  }

  function nameToHex (name) {
    return colorMap[name] ? `#${colorMap[name]}` : '#000'
  }

  function hexToRgb (hex) {
    const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i
    hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b)
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)

    return new RGBA(parseInt(result[1], 16), parseInt(result[2], 16), parseInt(result[3], 16), 255)
  }

  function rgbToHex (rgb) {
    const rgbComponents = rgb.substring(rgb.lastIndexOf('(') + 1, rgb.lastIndexOf(')')).split(',')
    const r = parseInt(rgbComponents[0], 10)
    const g = parseInt(rgbComponents[1], 10)
    const b = parseInt(rgbComponents[2], 10)

    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`
  }

  function rgbParse (rgb) {
    const res = rgb.replace(/[^0-9.,]+/g, '').split(',')
    const obj = {}
    const flags = ['r', 'g', 'b', 'a']
    for (let i = 0; i < res.length; i += 1) {
      obj[flags[i]] = parseFloat(res[i])
    }
    return new RGBA(obj.r, obj.g, obj.b, obj.a)
  }

  function hslParse (hsl) {
    var r
    var g
    var b
    var a
    var h
    var s
    var l
    var obj = {}
    const res = hsl.replace(/[^0-9.,]+/g, '').split(',').map(function (d) { return parseFloat(d) })
    h = res[0] / 360
    s = res[1] / 100
    l = res[2] / 100
    a = res[3]
    if (s === 0) {
      r = g = b = l
    } else {
      var hue2rgb = function hue2rgb (p, q, t) {
        if (t < 0) t += 1
        if (t > 1) t -= 1
        if (t < 1 / 6) return p + (q - p) * 6 * t
        if (t < 1 / 2) return q
        if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
        return p
      }

      var q = l < 0.5 ? l * (1 + s) : l + s - l * s
      var p = 2 * l - q
      r = hue2rgb(p, q, h + 1 / 3) * 255
      g = hue2rgb(p, q, h) * 255
      b = hue2rgb(p, q, h - 1 / 3) * 255
    }
    if (a !== undefined) obj.a = a
    return new RGBA(r, g, b, a)
  }

  function colorToRGB (val) {
    return val instanceof RGBA ? val : val.startsWith('#') ? hexToRgb(val)
      : val.startsWith('rgb') ? rgbParse(val)
        : val.startsWith('hsl') ? hslParse(val) : { r: 0, g: 0, b: 0, a: 255 }
  }

  function colorTransition (src, dest) {
    src = src || defaultColor
    dest = dest || defaultColor

    src = colorToRGB(src)
    dest = colorToRGB(dest)
    return function trans (f) {
      return `rgb(${Math.round(src.r + (dest.r - src.r) * f)},${Math.round(src.g + (dest.g - src.g) * f)},${Math.round(src.b + (dest.b - src.b) * f)})`
    }
  }

  function colorRGBtransition (src, dest) {
    src = src || defaultColor
    dest = dest || defaultColor

    src = colorToRGB(src)
    dest = colorToRGB(dest)
    return function trans (f) {
      return new RGBA(round(src.r + (dest.r - src.r) * f), round(src.g + (dest.g - src.g) * f), round(src.b + (dest.b - src.b) * f), round(src.a + (dest.a - src.a) * f))
    }
  }

  function rgbaInstance (r, g, b, a) {
    return new RGBA(r, g, b, a)
  }

  function isTypeColor (value) {
    return value instanceof RGBA || value.startsWith('#') || value.startsWith('rgb') || value.startsWith('hsl')
  }

  const colorMapper = {
    nameToHex: nameToHex,
    hexToRgb: hexToRgb,
    rgbToHex: rgbToHex,
    hslToRgb: hslParse,
    transition: colorTransition,
    transitionObj: colorRGBtransition,
    colorToRGB: colorToRGB,
    rgba: rgbaInstance,
    isTypeColor: isTypeColor
  }

  return colorMapper
}))
