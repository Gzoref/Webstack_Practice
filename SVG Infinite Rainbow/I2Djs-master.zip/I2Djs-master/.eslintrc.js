module.exports = {
    "extends": "standard"
};